// State Management
const state = {
  user: null, // { id, name, email, groupOrder, groupName, role, isAdmin, active }
  admins: [],
  criteria: [],
  groups: [],
  accounts: [],
  ratings: [],
  classStats: {},
  googleResources: {},
  searchQuery: '',
  adminAccountSearch: '',
  adminRatingGroupFilter: '',
  viewMode: 'table', // 'table' | 'cards'
  activeRateGroupOrder: null,
  adminProxyUploadGroupOrder: null
};

// Initialize app on DOMContentLoaded
document.addEventListener('DOMContentLoaded', async () => {
  loadSavedUser();
  bindEvents();
  await fetchPortalData();
});

function loadSavedUser() {
  try {
    const raw = localStorage.getItem('sci_portal_user');
    if (raw) {
      state.user = JSON.parse(raw);
      updateUserTopbar();
    }
  } catch (e) {
    console.warn('Could not load saved user:', e);
  }
}

function saveUser(user) {
  state.user = user;
  if (user) {
    localStorage.setItem('sci_portal_user', JSON.stringify(user));
  } else {
    localStorage.removeItem('sci_portal_user');
  }
  updateUserTopbar();
  renderAll();
}

function isUserAdmin() {
  if (!state.user) return false;
  return Boolean(
    state.user.isAdmin ||
      state.user.role === 'admin' ||
      (state.admins || []).some(e => e.toLowerCase() === (state.user.email || '').toLowerCase())
  );
}

function updateUserTopbar() {
  const badge = document.getElementById('user-badge');
  const loginBtn = document.getElementById('btn-open-login');
  const myTabBadge = document.getElementById('my-group-tab-badge');
  const adminTag = document.getElementById('user-display-admin');
  const adminNavTab = document.getElementById('nav-tab-admin');
  const masterExportBtn = document.getElementById('btn-master-export-excel');

  if (state.user) {
    badge.classList.remove('hidden');
    loginBtn.classList.add('hidden');
    document.getElementById('user-avatar').textContent = state.user.name.charAt(0);
    document.getElementById('user-display-name').textContent = `${state.user.name} (${state.user.id})`;
    document.getElementById('user-display-group').textContent = state.user.groupOrder
      ? `第 ${state.user.groupOrder} 組`
      : state.user.groupName;

    if (state.user.groupOrder) {
      myTabBadge.textContent = `第 ${state.user.groupOrder} 組`;
      myTabBadge.classList.remove('hidden');
    } else {
      myTabBadge.classList.add('hidden');
    }

    if (isUserAdmin()) {
      adminTag.classList.remove('hidden');
      adminNavTab.classList.remove('hidden');
      if (masterExportBtn) masterExportBtn.classList.remove('hidden');
    } else {
      adminTag.classList.add('hidden');
      adminNavTab.classList.add('hidden');
      if (masterExportBtn) masterExportBtn.classList.add('hidden');
      // If currently on admin tab and logged out of admin, return to scores tab
      if (document.getElementById('tab-admin').classList.contains('active')) {
        document.getElementById('nav-tab-scores').click();
      }
    }
  } else {
    badge.classList.add('hidden');
    loginBtn.classList.remove('hidden');
    myTabBadge.classList.add('hidden');
    adminTag.classList.add('hidden');
    adminNavTab.classList.add('hidden');
    if (masterExportBtn) masterExportBtn.classList.add('hidden');
  }
}

window.exportAllScoresExcel = async function () {
  if (!isUserAdmin()) {
    showToast('僅限管理員（如 s25101114@stu.edu.tw）可匯出分數總覽 Excel 檔', 'error');
    return;
  }

  showToast('正在產生「所有組別分數總覽 Excel (.xlsx)」檔案...', 'info');
  try {
    const res = await fetch(`/api/admin/export-excel?adminEmail=${encodeURIComponent(state.user.email)}`, {
      method: 'GET',
      headers: {
        'x-admin-email': state.user.email
      }
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      showToast(errData.error || '匯出 Excel 失敗', 'error');
      return;
    }

    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `科技文選_所有組別分數總覽表_${dateStr}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);

    showToast('已成功匯出並下載「科技文選_所有組別分數總覽表.xlsx」！', 'success');
  } catch (err) {
    showToast('匯出發生錯誤：' + err.message, 'error');
  }
};

async function fetchPortalData() {
  try {
    const res = await fetch('/api/portal-data');
    const data = await res.json();
    state.admins = data.admins || [];
    state.criteria = data.criteria || [];
    state.groups = data.groups || [];
    state.accounts = data.accounts || [];
    state.ratings = data.ratings || [];
    state.classStats = data.classStats || {};
    state.googleResources = data.googleResources || {};

    // Refresh current logged-in user's latest role/group from server accounts
    if (state.user) {
      const latest = state.accounts.find(
        a => a.email.toLowerCase() === (state.user.email || '').toLowerCase()
      );
      if (latest) {
        state.user = latest;
        localStorage.setItem('sci_portal_user', JSON.stringify(latest));
      }
    }

    updateUserTopbar();
    renderAll();
  } catch (err) {
    showToast('無法載入系統資料：' + err.message, 'error');
  }
}

function renderAll() {
  renderCriteriaChips();
  renderClassStats();
  renderMasterTable();
  renderGroupCards();
  renderMyGroupWorkspace();
  renderAdminBackend();
  renderCloudResources();
  renderQuickStudentPicker();
}

// 1. Criteria Chips (5 x 20 pts = 100 pts)
function renderCriteriaChips() {
  const container = document.getElementById('criteria-chips-list');
  container.innerHTML = state.criteria
    .map(
      c => `
      <span class="criterion-chip">
        <span>${escapeHtml(c.name)}</span>
        <strong>${c.maxScore}分 (${c.weight})</strong>
      </span>
    `
    )
    .join('');
}

// 2. Class Summary Stats
function renderClassStats() {
  const s = state.classStats;
  document.getElementById('stat-avg').textContent = (s.averageScore || 0).toFixed(1);
  document.getElementById('stat-max').textContent = (s.maxScore || 0).toFixed(1);
  document.getElementById('stat-min').textContent = (s.minScore || 0).toFixed(1);
  document.getElementById('stat-count').textContent = s.totalRatingsCount || 0;
}

function getFilteredGroups() {
  const q = state.searchQuery.trim().toLowerCase();
  if (!q) return state.groups;
  return state.groups.filter(g => {
    const memberText = g.members.map(m => `${m.name} ${m.id} ${m.email}`).join(' ').toLowerCase();
    return (
      `第${g.order}組`.includes(q) ||
      String(g.order) === q ||
      g.name.toLowerCase().includes(q) ||
      g.title.toLowerCase().includes(q) ||
      memberText.includes(q)
    );
  });
}

// 3. Master Grading Table (12 groups + Average/Max/Min footer)
function renderMasterTable() {
  const tbody = document.getElementById('grading-table-body');
  const tfoot = document.getElementById('grading-table-foot');
  const groups = getFilteredGroups();

  tbody.innerHTML = groups
    .map(g => {
      const isMyGroup = state.user && state.user.groupOrder === g.order;
      const memberNames = g.members.map(m => m.name).join('、');
      const memberIds = g.members.map(m => m.id).join('、');
      const hasScore = g.ratingCount > 0;

      const filesHtml = (g.files || [])
        .map(
          f => `
          <a href="${escapeAttr(f.url)}" target="_blank" rel="noopener" class="file-pill" title="開啟已上傳報告：${escapeAttr(f.name)}">
            📄 ${escapeHtml(truncate(f.name, 26))} ↗
          </a>
        `
        )
        .join('');

      const sourceLink =
        g.sourceUrl && g.sourceUrl.startsWith('http')
          ? `<a href="${escapeAttr(g.sourceUrl)}" target="_blank" rel="noopener" class="ext-link">參考連結 ↗</a>`
          : `<span class="score-empty">無</span>`;

      const scoreCell = val =>
        hasScore
          ? `<span class="score-num">${Number(val).toFixed(1)}</span>`
          : `<span class="score-empty">—</span>`;

      return `
        <tr class="${isMyGroup ? 'is-my-group' : ''}">
          <td class="col-order">
            <span class="order-badge">${g.order}</span>
          </td>
          <td>
            <div class="member-names">
              <span>${escapeHtml(memberNames)}</span>
              ${isMyGroup ? '<span class="my-group-pill">本組</span>' : ''}
            </div>
            <div class="member-ids">${escapeHtml(memberIds)}</div>
          </td>
          <td class="report-title-cell">
            <div>${escapeHtml(g.title || '未定')}</div>
            ${filesHtml ? `<div class="attached-files-inline">${filesHtml}</div>` : ''}
          </td>
          <td>${sourceLink}</td>
          <td class="col-score">${scoreCell(g.avgScores.content)}</td>
          <td class="col-score">${scoreCell(g.avgScores.visuals)}</td>
          <td class="col-score">${scoreCell(g.avgScores.delivery)}</td>
          <td class="col-score">${scoreCell(g.avgScores.qna)}</td>
          <td class="col-score">${scoreCell(g.avgScores.teamwork)}</td>
          <td class="col-total">
            <span class="total-pill ${hasScore ? '' : 'unscored'}">
              ${hasScore ? g.totalScore.toFixed(1) : '尚未評分'}
            </span>
            <span class="rating-count-sub">${g.ratingCount} 筆評分</span>
          </td>
          <td>
            <button class="btn ${isMyGroup ? 'btn-outline' : 'btn-primary'} btn-sm" onclick="openRateModal(${g.order})">
              ${isMyGroup ? '查看明細' : '評分 / 明細'}
            </button>
          </td>
        </tr>
      `;
    })
    .join('');

  const s = state.classStats;
  tfoot.innerHTML = `
    <tr>
      <td colspan="9">平均 (Average)</td>
      <td class="col-total">${(s.averageScore || 0).toFixed(1)}</td>
      <td></td>
    </tr>
    <tr>
      <td colspan="9">最高 (Max)</td>
      <td class="col-total" style="color: var(--accent);">${(s.maxScore || 0).toFixed(1)}</td>
      <td></td>
    </tr>
    <tr>
      <td colspan="9">最低 (Min)</td>
      <td class="col-total">${(s.minScore || 0).toFixed(1)}</td>
      <td></td>
    </tr>
  `;
}

// 4. Detailed Cards Grid View
function renderGroupCards() {
  const container = document.getElementById('groups-cards-container');
  const groups = getFilteredGroups();

  container.innerHTML = groups
    .map(g => {
      const isMyGroup = state.user && state.user.groupOrder === g.order;
      const memberNames = g.members.map(m => `${m.name} (${m.id})`).join('、');
      const hasScore = g.ratingCount > 0;

      const barsHtml = state.criteria
        .map(c => {
          const val = hasScore ? g.avgScores[c.key] : 0;
          const pct = Math.min(100, Math.round((val / 20) * 100));
          return `
            <div class="bar-row">
              <span>${escapeHtml(c.name)}</span>
              <div class="bar-track">
                <div class="bar-fill" style="width: ${pct}%;"></div>
              </div>
              <span class="bar-val">${hasScore ? val.toFixed(1) : '—'}<small>/20</small></span>
            </div>
          `;
        })
        .join('');

      const filesHtml = (g.files || [])
        .map(
          f => `
          <a href="${escapeAttr(f.url)}" target="_blank" rel="noopener" class="file-pill">
            📄 ${escapeHtml(truncate(f.name, 28))} ↗
          </a>
        `
        )
        .join('');

      return `
        <article class="group-card ${isMyGroup ? 'is-my-group' : ''}">
          <div>
            <div class="group-card-top">
              <div>
                <span class="group-order-pill">第 ${g.order} 組</span>
                ${isMyGroup ? '<span class="my-group-pill" style="margin-left:6px;">您的組別</span>' : ''}
              </div>
              <div style="text-align:right;">
                <span class="total-pill ${hasScore ? '' : 'unscored'}">
                  ${hasScore ? `${g.totalScore.toFixed(1)} / 100 分` : '尚未評分'}
                </span>
                <span class="rating-count-sub">共 ${g.ratingCount} 人評分</span>
              </div>
            </div>

            <h3 class="group-card-title">${escapeHtml(g.title || '未定')}</h3>
            <p class="group-card-members">組員：${escapeHtml(memberNames)}</p>
            ${filesHtml ? `<div class="attached-files-inline" style="margin-top:8px;">${filesHtml}</div>` : ''}
          </div>

          <div class="card-criteria-bars">
            ${barsHtml}
          </div>

          <div class="group-card-footer">
            <div>
              ${
                g.sourceUrl && g.sourceUrl.startsWith('http')
                  ? `<a href="${escapeAttr(g.sourceUrl)}" target="_blank" rel="noopener" class="ext-link">參考文章 / 簡報來源 ↗</a>`
                  : `<span class="score-empty" style="font-size:12px;">尚未提供參考網址</span>`
              }
            </div>
            <button class="btn ${isMyGroup ? 'btn-outline' : 'btn-primary'} btn-sm" onclick="openRateModal(${g.order})">
              ${isMyGroup ? '檢視本組評分明細' : '線上評分 / 明細'}
            </button>
          </div>
        </article>
      `;
    })
    .join('');
}

// 5. My Group Upload & Report Management Workspace
function renderMyGroupWorkspace() {
  const unauthCard = document.getElementById('my-group-unauth');
  const workspace = document.getElementById('my-group-workspace');

  if (!state.user || !state.user.groupOrder) {
    unauthCard.classList.remove('hidden');
    workspace.classList.add('hidden');
    return;
  }

  const myGroup = state.groups.find(g => g.order === state.user.groupOrder);
  if (!myGroup) {
    unauthCard.classList.remove('hidden');
    workspace.classList.add('hidden');
    return;
  }

  unauthCard.classList.add('hidden');
  workspace.classList.remove('hidden');

  document.getElementById('my-group-order-pill').textContent = `第 ${myGroup.order} 組（上台順序 #${myGroup.order}）`;
  document.getElementById('my-group-heading').textContent = `${myGroup.name} — 報告與簡報上傳管理`;

  document.getElementById('my-group-members-list').innerHTML = myGroup.members
    .map(
      m => `
      <div class="roster-member-chip">
        <strong>${escapeHtml(m.name)} ${m.role === 'admin' ? '<span class="admin-badge-pill">管理員</span>' : ''}</strong>
        <span>學號：${escapeHtml(m.id)} · ${escapeHtml(m.email)}</span>
      </div>
    `
    )
    .join('');

  document.getElementById('input-report-title').value = myGroup.title || '';
  document.getElementById('input-report-source').value = myGroup.sourceUrl || '';

  const hasScore = myGroup.ratingCount > 0;
  document.getElementById('my-group-score-snapshot').innerHTML = `
    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
      <strong>本組目前評分統計（共 ${myGroup.ratingCount} 筆同儕評分）</strong>
      <span class="total-pill ${hasScore ? '' : 'unscored'}">
        ${hasScore ? `${myGroup.totalScore.toFixed(1)} / 100 分` : '尚無評分'}
      </span>
    </div>
    <p style="font-size:12.5px; color:var(--text-secondary);">
      內容掌握：<strong>${hasScore ? myGroup.avgScores.content : '—'}</strong>/20 ·
      簡報製作：<strong>${hasScore ? myGroup.avgScores.visuals : '—'}</strong>/20 ·
      口語台風：<strong>${hasScore ? myGroup.avgScores.delivery : '—'}</strong>/20 ·
      時間問答：<strong>${hasScore ? myGroup.avgScores.qna : '—'}</strong>/20 ·
      團隊表現：<strong>${hasScore ? myGroup.avgScores.teamwork : '—'}</strong>/20
    </p>
  `;

  const filesContainer = document.getElementById('my-group-files-list');
  const files = myGroup.files || [];
  if (files.length === 0) {
    filesContainer.innerHTML = `
      <div class="file-item-card">
        <div class="file-item-meta">
          <span class="file-item-name" style="color:var(--text-muted);">目前尚未上傳簡報檔案</span>
          <span class="file-item-sub">請使用上方上傳區選擇 PDF 或 PPTX 簡報上傳，系統將自動同步至 Google Drive。</span>
        </div>
      </div>
    `;
  } else {
    filesContainer.innerHTML = files
      .map(
        f => `
        <div class="file-item-card">
          <div class="file-item-meta">
            <span class="file-item-name">📄 ${escapeHtml(f.name)}</span>
            <span class="file-item-sub">
              上傳者：${escapeHtml(f.uploadedBy || '組員')} · 
              ${f.driveUrl ? '已同步至 Google Drive 雲端資料夾' : '已儲存於網站伺服器'}
            </span>
          </div>
          <div style="display:flex; gap:8px;">
            <a href="${escapeAttr(f.url)}" target="_blank" rel="noopener" class="btn btn-outline btn-sm">開啟 / 下載 ↗</a>
          </div>
        </div>
      `
      )
      .join('');
  }
}

// ==================== 6. ADMIN BACKEND & ACCOUNT MANAGEMENT ====================
function renderAdminBackend() {
  if (!isUserAdmin()) return;

  // Render Admin KPI strip
  const totalFiles = state.groups.reduce((acc, g) => acc + (g.files ? g.files.length : 0), 0);
  const kpiStrip = document.getElementById('admin-kpi-strip');
  kpiStrip.innerHTML = `
    <div class="admin-kpi-card">
      <div class="admin-kpi-label">系統總帳號數</div>
      <div class="admin-kpi-val">${state.accounts.length} <small style="font-size:13px;font-weight:500;">位學生</small></div>
    </div>
    <div class="admin-kpi-card">
      <div class="admin-kpi-label">系統管理員數</div>
      <div class="admin-kpi-val" style="color:#b45309;">${state.accounts.filter(a => a.isAdmin).length} <small style="font-size:13px;font-weight:500;">位管理員</small></div>
    </div>
    <div class="admin-kpi-card">
      <div class="admin-kpi-label">已收到評分組數 / 總組數</div>
      <div class="admin-kpi-val">${state.classStats.scoredGroupsCount || 0} / ${state.groups.length} <small style="font-size:13px;font-weight:500;">組</small></div>
    </div>
    <div class="admin-kpi-card">
      <div class="admin-kpi-label">已上傳簡報與連結數</div>
      <div class="admin-kpi-val" style="color:var(--accent);">${totalFiles} <small style="font-size:13px;font-weight:500;">份檔案</small></div>
    </div>
  `;

  // Render Section 1: Accounts Table
  const q = state.adminAccountSearch.trim().toLowerCase();
  const filteredAccounts = state.accounts.filter(a => {
    if (!q) return true;
    return (
      a.name.toLowerCase().includes(q) ||
      a.id.toLowerCase().includes(q) ||
      a.email.toLowerCase().includes(q) ||
      (a.groupName || '').toLowerCase().includes(q)
    );
  });

  const accTbody = document.getElementById('admin-accounts-tbody');
  accTbody.innerHTML = filteredAccounts
    .map(acc => {
      const isPrimaryAdmin = acc.email.toLowerCase() === 's25101114@stu.edu.tw';
      return `
        <tr>
          <td>
            <span class="group-order-pill">${acc.groupOrder ? `第 ${acc.groupOrder} 組` : '未分組'}</span>
          </td>
          <td>
            <strong>${escapeHtml(acc.name)}</strong>
            <div class="member-ids">學號：${escapeHtml(acc.id)}</div>
          </td>
          <td style="font-family:var(--font-mono); font-size:12.5px;">
            ${escapeHtml(acc.email)}
          </td>
          <td>
            ${
              acc.isAdmin
                ? '<span class="admin-badge-pill">系統管理員 (Admin)</span>'
                : '<span class="role-pill-student">一般學生 (Student)</span>'
            }
          </td>
          <td>
            ${
              acc.active !== false
                ? '<span class="status-pill-active">啟用中</span>'
                : '<span class="status-pill-disabled">已停用</span>'
            }
          </td>
          <td>
            <div style="display:flex; gap:6px; flex-wrap:wrap;">
              <button type="button" class="btn btn-outline btn-sm" onclick="populateAdminEditAccount('${escapeAttr(acc.email)}')">
                編輯帳號
              </button>
              ${
                !isPrimaryAdmin
                  ? `<button type="button" class="btn btn-outline btn-sm" onclick="toggleAccountAdminRole('${escapeAttr(acc.email)}')">
                      ${acc.isAdmin ? '設為一般學生' : '設為管理員'}
                    </button>
                    <button type="button" class="btn-danger-sm" onclick="deleteAdminAccount('${escapeAttr(acc.email)}')">
                      刪除
                    </button>`
                  : `<span style="font-size:11.5px; color:var(--text-muted); padding:4px 6px;">預設主管理員</span>`
              }
            </div>
          </td>
        </tr>
      `;
    })
    .join('');

  // Render Section 2: All 12 Groups Report & File Management
  const grpTbody = document.getElementById('admin-groups-tbody');
  grpTbody.innerHTML = state.groups
    .map(g => {
      const membersStr = g.members.map(m => `${m.name}(${m.id})`).join('、');
      const filesListHtml = (g.files || [])
        .map(
          f => `
          <div style="display:flex; align-items:center; justify-content:space-between; gap:6px; margin-bottom:4px;">
            <a href="${escapeAttr(f.url)}" target="_blank" rel="noopener" class="file-pill">
              📄 ${escapeHtml(truncate(f.name, 22))} ↗
            </a>
            <button type="button" class="btn-danger-sm" style="padding:1px 6px; font-size:11px;" onclick="adminDeleteGroupFile(${g.order}, '${escapeAttr(f.id)}')">
              移除
            </button>
          </div>
        `
        )
        .join('');

      return `
        <tr>
          <td class="col-order"><span class="order-badge">${g.order}</span></td>
          <td style="font-size:12.5px;">${escapeHtml(membersStr || '無組員')}</td>
          <td>
            <input type="text" class="admin-inline-input" id="admin-grp-title-${g.order}" value="${escapeAttr(g.title || '')}" />
          </td>
          <td>
            <input type="text" class="admin-inline-input" id="admin-grp-source-${g.order}" value="${escapeAttr(g.sourceUrl || '')}" placeholder="https://..." />
          </td>
          <td>
            ${filesListHtml || '<div style="font-size:12px;color:var(--text-muted);margin-bottom:4px;">尚未上傳簡報</div>'}
            <button type="button" class="btn btn-outline btn-sm" onclick="triggerAdminProxyUpload(${g.order})">
              + 代傳簡報檔案
            </button>
          </td>
          <td>
            <button type="button" class="btn btn-primary btn-sm" onclick="adminSaveGroupInfo(${g.order})">
              儲存並同步
            </button>
          </td>
        </tr>
      `;
    })
    .join('');

  // Render Section 3: All Peer Ratings Table
  const filterOrder = state.adminRatingGroupFilter ? Number(state.adminRatingGroupFilter) : null;
  const filteredRatings = state.ratings.filter(r => (!filterOrder ? true : r.groupOrder === filterOrder));

  const ratingsTbody = document.getElementById('admin-ratings-tbody');
  if (filteredRatings.length === 0) {
    ratingsTbody.innerHTML = `
      <tr>
        <td colspan="11" style="text-align:center; padding:24px; color:var(--text-muted);">
          沒有符合篩選條件的評分紀錄
        </td>
      </tr>
    `;
  } else {
    ratingsTbody.innerHTML = filteredRatings
      .map(r => {
        const s = r.scores || {};
        const tot = Number(s.content || 0) + Number(s.visuals || 0) + Number(s.delivery || 0) + Number(s.qna || 0) + Number(s.teamwork || 0);
        return `
          <tr>
            <td><span class="group-order-pill">第 ${r.groupOrder} 組</span></td>
            <td>
              <strong>${escapeHtml(r.reviewerName)}</strong>
              <div class="member-ids">${escapeHtml(r.reviewerEmail)}</div>
            </td>
            <td style="font-size:12px; color:var(--text-muted);">${escapeHtml(r.timestamp)}</td>
            <td class="col-score">${s.content}</td>
            <td class="col-score">${s.visuals}</td>
            <td class="col-score">${s.delivery}</td>
            <td class="col-score">${s.qna}</td>
            <td class="col-score">${s.teamwork}</td>
            <td class="col-total"><span class="total-pill">${tot}</span></td>
            <td style="max-width:200px; font-size:12.5px;">${escapeHtml(r.comment || '—')}</td>
            <td>
              <button type="button" class="btn-danger-sm" onclick="adminDeleteRating('${escapeAttr(r.id)}')">
                刪除此筆
              </button>
            </td>
          </tr>
        `;
      })
      .join('');
  }
}

// Admin Account Actions
window.populateAdminEditAccount = function (email) {
  const acc = state.accounts.find(a => a.email.toLowerCase() === email.toLowerCase());
  if (!acc) return;

  document.getElementById('admin-account-form-title').textContent = `編輯帳號：${acc.name} (${acc.id})`;
  document.getElementById('admin-acc-original-email').value = acc.email;
  document.getElementById('admin-acc-id').value = acc.id;
  document.getElementById('admin-acc-name').value = acc.name;
  document.getElementById('admin-acc-email').value = acc.email;
  document.getElementById('admin-acc-group').value = acc.groupOrder ? String(acc.groupOrder) : '';
  document.getElementById('admin-acc-role').value = acc.isAdmin ? 'admin' : 'student';
  document.getElementById('admin-acc-active').value = acc.active !== false ? 'true' : 'false';

  document.getElementById('btn-admin-save-acc').textContent = '更新帳號設定';
  document.getElementById('btn-admin-cancel-edit').classList.remove('hidden');
};

function resetAdminAccountForm() {
  document.getElementById('admin-account-form-title').textContent = '新增學生 / 管理員帳號';
  document.getElementById('admin-acc-original-email').value = '';
  document.getElementById('admin-acc-id').value = '';
  document.getElementById('admin-acc-name').value = '';
  document.getElementById('admin-acc-email').value = '';
  document.getElementById('admin-acc-group').value = '';
  document.getElementById('admin-acc-role').value = 'student';
  document.getElementById('admin-acc-active').value = 'true';
  document.getElementById('btn-admin-save-acc').textContent = '儲存帳號設定';
  document.getElementById('btn-admin-cancel-edit').classList.add('hidden');
}

window.toggleAccountAdminRole = async function (email) {
  if (!isUserAdmin()) return;
  const acc = state.accounts.find(a => a.email.toLowerCase() === email.toLowerCase());
  if (!acc) return;

  const newRole = acc.isAdmin ? 'student' : 'admin';
  try {
    const res = await fetch(`/api/admin/accounts/${encodeURIComponent(acc.email)}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'x-admin-email': state.user.email
      },
      body: JSON.stringify({
        id: acc.id,
        name: acc.name,
        email: acc.email,
        groupOrder: acc.groupOrder,
        role: newRole,
        active: acc.active
      })
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || '權限變更失敗', 'error');
      return;
    }
    await fetchPortalData();
    showToast(`已將「${acc.name}」的角色更新為 ${newRole === 'admin' ? '系統管理員' : '一般學生'}！`, 'success');
  } catch (err) {
    showToast('操作失敗：' + err.message, 'error');
  }
};

window.deleteAdminAccount = async function (email) {
  if (!isUserAdmin()) return;
  const acc = state.accounts.find(a => a.email.toLowerCase() === email.toLowerCase());
  if (!acc) return;
  if (!confirm(`確定要刪除帳號「${acc.name} (${acc.email})」嗎？此操作也會同步更新分組名單。`)) return;

  try {
    const res = await fetch(`/api/admin/accounts/${encodeURIComponent(acc.email)}`, {
      method: 'DELETE',
      headers: { 'x-admin-email': state.user.email }
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || '刪除失敗', 'error');
      return;
    }
    await fetchPortalData();
    showToast(`已刪除帳號 ${acc.name} (${acc.email})`, 'success');
  } catch (err) {
    showToast('刪除失敗：' + err.message, 'error');
  }
};

window.adminSaveGroupInfo = async function (groupOrder) {
  if (!isUserAdmin()) return;
  const title = document.getElementById(`admin-grp-title-${groupOrder}`).value;
  const sourceUrl = document.getElementById(`admin-grp-source-${groupOrder}`).value;

  try {
    const res = await fetch(`/api/groups/${groupOrder}/info`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, sourceUrl })
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || '儲存失敗', 'error');
      return;
    }
    await fetchPortalData();
    showToast(`已更新第 ${groupOrder} 組報告資訊並同步至 Google 試算表！`, 'success');
  } catch (err) {
    showToast('儲存失敗：' + err.message, 'error');
  }
};

window.triggerAdminProxyUpload = function (groupOrder) {
  state.adminProxyUploadGroupOrder = groupOrder;
  const input = document.getElementById('admin-proxy-file-input');
  input.value = '';
  input.click();
};

window.adminDeleteGroupFile = async function (groupOrder, fileId) {
  if (!isUserAdmin()) return;
  if (!confirm(`確定要移除第 ${groupOrder} 組的這份簡報檔案紀錄嗎？`)) return;

  try {
    const res = await fetch(`/api/admin/groups/${groupOrder}/files/${encodeURIComponent(fileId)}`, {
      method: 'DELETE',
      headers: { 'x-admin-email': state.user.email }
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || '移除失敗', 'error');
      return;
    }
    await fetchPortalData();
    showToast(`已移除第 ${groupOrder} 組的檔案紀錄`, 'success');
  } catch (err) {
    showToast('移除失敗：' + err.message, 'error');
  }
};

window.adminDeleteRating = async function (ratingId) {
  if (!isUserAdmin()) return;
  if (!confirm('確定要刪除此筆評分紀錄嗎？刪除後將自動重算該組平均分數並同步至 Google 試算表總表。')) return;

  try {
    const res = await fetch(`/api/admin/ratings/${encodeURIComponent(ratingId)}`, {
      method: 'DELETE',
      headers: { 'x-admin-email': state.user.email }
    });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || '刪除失敗', 'error');
      return;
    }
    await fetchPortalData();
    showToast('已刪除此筆評分紀錄並重新同步總表！', 'success');
  } catch (err) {
    showToast('刪除失敗：' + err.message, 'error');
  }
};

// 7. Cloud Resources Directory (Master Sheets + All 12 Groups Forms, Response Sheets & QR Codes)
function renderCloudResources() {
  const container = document.getElementById('cloud-resources-list');
  const masterItems = [
    {
      type: 'Google Sheets 總表',
      title: '科技文選分組報告評分表（12組總表・各項20分 & 表單試算表總連結）',
      url: 'https://docs.google.com/spreadsheets/d/1iBFfy31wZxUXPb0ojm3D4UCrWNSisRS4UCS4_mlzWWE/edit'
    },
    {
      type: 'Google Sheets 分組名單',
      title: '科技文選分組 (回覆) — 學生學號與上台順序名單',
      url: 'https://docs.google.com/spreadsheets/d/1riwmmeEARbTstBruzx5aaF6hWVgNOLRo-wgKhi3MG4I/edit'
    },
    {
      type: 'Google Drive 資料夾',
      title: '科技文選報告 ( 評分表 & QR Code & 簡報上傳區 )',
      url: 'https://drive.google.com/drive/folders/19oLtHpGGpNsq_0qR5EDou4x4rB0ANxCH'
    }
  ];

  const masterHtml = masterItems
    .map(
      item => `
      <div class="cloud-card">
        <div>
          <span class="cloud-card-type">${escapeHtml(item.type)}</span>
          <div class="cloud-card-title" style="margin-top:4px;">${escapeHtml(item.title)}</div>
        </div>
        <div>
          <a href="${escapeAttr(item.url)}" target="_blank" rel="noopener" class="ext-link" style="display:inline-block;">
            開啟 Google 雲端檔案 ↗
          </a>
        </div>
      </div>
    `
    )
    .join('');

  const groupCardsHtml = state.groups
    .map(g => {
      const membersStr = g.members.map(m => `${m.name}(${m.id})`).join('、');
      const formUrl = g.formUrl || '#';
      const sheetUrl = g.sheetUrl || (g.sheetId ? `https://docs.google.com/spreadsheets/d/${g.sheetId}/edit` : '#');
      const qrDriveUrl = g.qrDriveUrl || '#';
      const qrLocalUrl = g.qrLocalUrl || `/qrcodes/group-${g.order}.png`;

      return `
        <div class="cloud-card" style="background: var(--bg-surface);">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
            <div style="flex:1;">
              <span class="cloud-card-type">第 ${g.order} 組（${escapeHtml(g.name)}）</span>
              <div class="cloud-card-title" style="margin-top:4px;">${escapeHtml(g.title || '未定')}</div>
              <div style="font-size:12px; color:var(--text-secondary); margin-top:4px;">
                組員：${escapeHtml(membersStr)}
              </div>
            </div>
            <a href="${escapeAttr(qrLocalUrl)}" target="_blank" rel="noopener" title="點擊放大第 ${g.order} 組 QR Code">
              <img
                src="${escapeAttr(qrLocalUrl)}"
                alt="第 ${g.order} 組 QR Code"
                style="width:74px; height:74px; object-fit:contain; border:1px solid var(--border-color); border-radius:6px; background:#fff; padding:2px;"
              />
            </a>
          </div>
          <div style="display:flex; flex-wrap:wrap; gap:6px; margin-top:6px;">
            <a href="${escapeAttr(formUrl)}" target="_blank" rel="noopener" class="btn btn-primary btn-sm">
              📝 評分表單 (Form) ↗
            </a>
            <a href="${escapeAttr(sheetUrl)}" target="_blank" rel="noopener" class="btn btn-outline btn-sm">
              📊 回覆試算表 (Sheet) ↗
            </a>
            <a href="${escapeAttr(qrDriveUrl)}" target="_blank" rel="noopener" class="btn btn-outline btn-sm">
              🔳 雲端 QR Code ↗
            </a>
          </div>
        </div>
      `;
    })
    .join('');

  container.innerHTML = masterHtml + groupCardsHtml;
}

// 8. Quick Student Picker inside Login Modal
function renderQuickStudentPicker() {
  const grid = document.getElementById('quick-student-grid');
  const buttons = [];

  for (const g of state.groups) {
    for (const m of g.members) {
      const isAdmin = m.role === 'admin' || (state.admins || []).includes(m.email.toLowerCase());
      buttons.push(`
        <button type="button" class="student-pick-btn" onclick="quickLogin('${escapeAttr(m.email)}')">
          <span class="pick-group-tag">
            第 ${g.order} 組 ${isAdmin ? '· ★ 管理員' : ''}
          </span>
          <span class="pick-name">${escapeHtml(m.name)} (${escapeHtml(m.id)})</span>
          <span class="pick-email">${escapeHtml(m.email)}</span>
        </button>
      `);
    }
  }

  grid.innerHTML = buttons.join('');
}

window.quickLogin = async function (emailOrId) {
  document.getElementById('input-login-account').value = emailOrId;
  await performLogin(emailOrId);
};

async function performLogin(emailOrId) {
  const errEl = document.getElementById('login-error-msg');
  errEl.classList.add('hidden');

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emailOrId })
    });
    const data = await res.json();
    if (!res.ok) {
      errEl.textContent = data.error || '登入失敗';
      errEl.classList.remove('hidden');
      return;
    }

    saveUser(data.user);
    closeModal('modal-login');

    if (data.user.isAdmin || data.user.role === 'admin') {
      showToast(`歡迎管理員 ${data.user.name} (${data.user.email}) 登入！已解鎖「管理員後台與帳號管理」`, 'success');
    } else {
      showToast(`歡迎登入！${data.user.name}（第 ${data.user.groupOrder || '—'} 組）`, 'success');
    }
  } catch (err) {
    errEl.textContent = '網路連線異常：' + err.message;
    errEl.classList.remove('hidden');
  }
}

// 9. Open Rate & Detailed Breakdown Modal for a Group (5 criteria x 20 pts = 100 pts)
window.openRateModal = function (groupOrder) {
  const group = state.groups.find(g => g.order === Number(groupOrder));
  if (!group) return;

  state.activeRateGroupOrder = group.order;
  document.getElementById('rate-group-order-input').value = group.order;
  document.getElementById('rate-modal-order').textContent = `第 ${group.order} 組`;
  document.getElementById('rate-modal-members').textContent = `組員：${group.members.map(m => `${m.name} (${m.id})`).join('、')}`;
  document.getElementById('rate-modal-title').textContent = group.title || '未定';

  let existingRating = null;
  if (state.user) {
    existingRating = (group.ratings || []).find(
      r => r.reviewerEmail.toLowerCase() === state.user.email.toLowerCase()
    );
    document.getElementById('rate-identity-tag').textContent = `評分者：${state.user.name} (${state.user.id})`;
  } else {
    document.getElementById('rate-identity-tag').textContent = '評分者：尚未登入（點擊送出時將引導登入）';
  }

  const initialScores = existingRating
    ? existingRating.scores
    : { content: 16, visuals: 16, delivery: 16, qna: 16, teamwork: 16 };

  const slidersContainer = document.getElementById('rate-sliders-container');
  slidersContainer.innerHTML = state.criteria
    .map(c => {
      const val = initialScores[c.key] !== undefined ? initialScores[c.key] : 16;
      return `
        <div class="criterion-slider-card">
          <div class="slider-top">
            <div>
              <span class="slider-label-title">${escapeHtml(c.name)}</span>
              <span class="slider-label-en">${escapeHtml(c.en)}</span>
            </div>
            <div class="slider-score-box">
              <input
                type="number"
                min="0"
                max="20"
                step="1"
                value="${val}"
                id="num-score-${c.key}"
                data-criterion="${c.key}"
                class="slider-score-input"
              />
              <span>/ 20 分</span>
            </div>
          </div>
          <div class="slider-controls-row">
            <input
              type="range"
              min="0"
              max="20"
              step="1"
              value="${val}"
              id="range-score-${c.key}"
              data-criterion="${c.key}"
              class="slider-range"
            />
            <div class="preset-btns">
              <button type="button" class="preset-btn" onclick="setCriterionScore('${c.key}', 12)">12</button>
              <button type="button" class="preset-btn" onclick="setCriterionScore('${c.key}', 16)">16</button>
              <button type="button" class="preset-btn" onclick="setCriterionScore('${c.key}', 18)">18</button>
              <button type="button" class="preset-btn" onclick="setCriterionScore('${c.key}', 20)">20</button>
            </div>
          </div>
        </div>
      `;
    })
    .join('');

  document.getElementById('rate-comment-input').value = existingRating ? existingRating.comment || '' : '';

  state.criteria.forEach(c => {
    const rangeEl = document.getElementById(`range-score-${c.key}`);
    const numEl = document.getElementById(`num-score-${c.key}`);
    rangeEl.addEventListener('input', () => {
      numEl.value = rangeEl.value;
      updateLiveRateTotal();
    });
    numEl.addEventListener('input', () => {
      let v = Number(numEl.value);
      if (v < 0) v = 0;
      if (v > 20) v = 20;
      rangeEl.value = v;
      updateLiveRateTotal();
    });
  });

  updateLiveRateTotal();

  const isSelfGroup = state.user && state.user.groupOrder === group.order;
  const selfWarn = document.getElementById('rate-self-warning');
  const submitBtn = document.getElementById('btn-submit-rating');
  if (isSelfGroup) {
    selfWarn.classList.remove('hidden');
    submitBtn.disabled = true;
    submitBtn.textContent = '本組組員不可評分自己的組別';
  } else {
    selfWarn.classList.add('hidden');
    submitBtn.disabled = false;
    submitBtn.textContent = existingRating
      ? '更新我的評分並同步至 Google 試算表'
      : '送出評分並同步至 Google 試算表';
  }

  document.getElementById('rate-records-count').textContent = `${group.ratingCount} 筆評分`;
  const hasScore = group.ratingCount > 0;

  document.getElementById('rate-breakdown-bars').innerHTML = state.criteria
    .map(c => {
      const avg = hasScore ? group.avgScores[c.key] : 0;
      const pct = Math.min(100, Math.round((avg / 20) * 100));
      return `
        <div class="bar-row">
          <span>${escapeHtml(c.name)}</span>
          <div class="bar-track">
            <div class="bar-fill" style="width: ${pct}%;"></div>
          </div>
          <span class="bar-val">${hasScore ? avg.toFixed(1) : '—'}<small>/20</small></span>
        </div>
      `;
    })
    .join('');

  const recordsTbody = document.getElementById('rate-records-tbody');
  if (!group.ratings || group.ratings.length === 0) {
    recordsTbody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align:center; color:var(--text-muted); padding:18px;">
          目前尚無評分紀錄，歡迎成為第一位評分者！
        </td>
      </tr>
    `;
  } else {
    recordsTbody.innerHTML = group.ratings
      .map(r => {
        const s = r.scores;
        const tot = Number(s.content) + Number(s.visuals) + Number(s.delivery) + Number(s.qna) + Number(s.teamwork);
        return `
          <tr>
            <td>
              <strong>${escapeHtml(r.reviewerName || r.reviewerEmail.split('@')[0])}</strong>
              <div style="font-size:10.5px; color:var(--text-muted);">${escapeHtml(r.reviewerEmail)}</div>
            </td>
            <td>${s.content}</td>
            <td>${s.visuals}</td>
            <td>${s.delivery}</td>
            <td>${s.qna}</td>
            <td>${s.teamwork}</td>
            <td><strong>${tot}</strong></td>
          </tr>
        `;
      })
      .join('');
  }

  const commentsFeed = document.getElementById('rate-comments-list');
  const comments = group.comments || [];
  commentsFeed.innerHTML = comments
    .map(
      c => `
      <div class="comment-bubble">
        <strong>${escapeHtml(c.reviewerName)}：</strong>
        <span>${escapeHtml(c.comment)}</span>
      </div>
    `
    )
    .join('');

  openModal('modal-rate');
};

window.setCriterionScore = function (key, score) {
  const rangeEl = document.getElementById(`range-score-${key}`);
  const numEl = document.getElementById(`num-score-${key}`);
  if (rangeEl && numEl) {
    rangeEl.value = score;
    numEl.value = score;
    updateLiveRateTotal();
  }
};

function updateLiveRateTotal() {
  let sum = 0;
  state.criteria.forEach(c => {
    const numEl = document.getElementById(`num-score-${c.key}`);
    if (numEl) {
      let val = Number(numEl.value) || 0;
      if (val < 0) val = 0;
      if (val > 20) val = 20;
      sum += val;
    }
  });
  document.getElementById('rate-live-total').textContent = sum;
}

// ==================== EVENT LISTENERS ====================
function bindEvents() {
  document.getElementById('btn-open-login').addEventListener('click', () => openModal('modal-login'));
  document.getElementById('btn-switch-user').addEventListener('click', () => openModal('modal-login'));
  document.getElementById('btn-unauth-login').addEventListener('click', () => openModal('modal-login'));

  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      closeModal(btn.getAttribute('data-close-modal'));
    });
  });

  document.getElementById('form-login').addEventListener('submit', async e => {
    e.preventDefault();
    const val = document.getElementById('input-login-account').value;
    await performLogin(val);
  });

  // Primary Workspace Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => {
        p.classList.remove('active');
        p.classList.add('hidden');
      });

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      const targetPanel = document.getElementById(targetId);
      targetPanel.classList.remove('hidden');
      targetPanel.classList.add('active');

      const filterControls = document.getElementById('scores-filter-controls');
      if (targetId === 'tab-all-scores') {
        filterControls.classList.remove('hidden');
      } else {
        filterControls.classList.add('hidden');
      }
    });
  });

  // Admin Subtabs Navigation
  document.querySelectorAll('.admin-subtab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.admin-subtab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.admin-section').forEach(sec => {
        sec.classList.remove('active');
        sec.classList.add('hidden');
      });

      btn.classList.add('active');
      const secId = btn.getAttribute('data-admin-section');
      const secEl = document.getElementById(secId);
      secEl.classList.remove('hidden');
      secEl.classList.add('active');
    });
  });

  // Admin Account Create / Edit Form Submit
  document.getElementById('form-admin-account').addEventListener('submit', async e => {
    e.preventDefault();
    if (!isUserAdmin()) return;

    const originalEmail = document.getElementById('admin-acc-original-email').value.trim();
    const payload = {
      id: document.getElementById('admin-acc-id').value.trim(),
      name: document.getElementById('admin-acc-name').value.trim(),
      email: document.getElementById('admin-acc-email').value.trim(),
      groupOrder: document.getElementById('admin-acc-group').value,
      role: document.getElementById('admin-acc-role').value,
      active: document.getElementById('admin-acc-active').value === 'true'
    };

    const isEdit = Boolean(originalEmail);
    const url = isEdit
      ? `/api/admin/accounts/${encodeURIComponent(originalEmail)}`
      : '/api/admin/accounts';
    const method = isEdit ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'x-admin-email': state.user.email
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || '儲存帳號失敗', 'error');
        return;
      }

      resetAdminAccountForm();
      await fetchPortalData();
      showToast(isEdit ? '已更新帳號設定並同步分組表！' : '已成功新增帳號並同步分組表！', 'success');
    } catch (err) {
      showToast('儲存帳號發生錯誤：' + err.message, 'error');
    }
  });

  document.getElementById('btn-admin-cancel-edit').addEventListener('click', () => {
    resetAdminAccountForm();
  });

  document.getElementById('admin-search-accounts').addEventListener('input', e => {
    state.adminAccountSearch = e.target.value;
    renderAdminBackend();
  });

  document.getElementById('admin-filter-rating-group').addEventListener('change', e => {
    state.adminRatingGroupFilter = e.target.value;
    renderAdminBackend();
  });

  // Admin Proxy File Upload Handler
  const proxyInput = document.getElementById('admin-proxy-file-input');
  proxyInput.addEventListener('change', async () => {
    if (!proxyInput.files || !proxyInput.files[0] || !state.adminProxyUploadGroupOrder) return;
    const groupOrder = state.adminProxyUploadGroupOrder;
    const file = proxyInput.files[0];

    const formData = new FormData();
    formData.append('file', file);
    formData.append('uploadedBy', `管理員代傳 (${state.user.name})`);

    showToast(`正在為第 ${groupOrder} 組上傳簡報至 Google Drive...`, 'info');
    try {
      const res = await fetch(`/api/groups/${groupOrder}/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || '代傳失敗', 'error');
        return;
      }
      await fetchPortalData();
      showToast(`已成功為第 ${groupOrder} 組上傳簡報「${data.file.name}」！`, 'success');
    } catch (err) {
      showToast('代傳錯誤：' + err.message, 'error');
    }
  });

  // Search Input
  document.getElementById('search-groups').addEventListener('input', e => {
    state.searchQuery = e.target.value;
    renderMasterTable();
    renderGroupCards();
  });

  // Table vs Cards View Toggle
  const btnTable = document.getElementById('btn-view-table');
  const btnCards = document.getElementById('btn-view-cards');
  btnTable.addEventListener('click', () => {
    btnTable.classList.add('active');
    btnCards.classList.remove('active');
    document.getElementById('master-table-container').classList.remove('hidden');
    document.getElementById('groups-cards-container').classList.add('hidden');
  });
  btnCards.addEventListener('click', () => {
    btnCards.classList.add('active');
    btnTable.classList.remove('active');
    document.getElementById('groups-cards-container').classList.remove('hidden');
    document.getElementById('master-table-container').classList.add('hidden');
  });

  // Submit Rating Form
  document.getElementById('form-rate-group').addEventListener('submit', async e => {
    e.preventDefault();
    if (!state.user) {
      closeModal('modal-rate');
      openModal('modal-login');
      showToast('請先登入您的學生帳號再送出評分', 'error');
      return;
    }

    const groupOrder = Number(document.getElementById('rate-group-order-input').value);
    const scores = {};
    state.criteria.forEach(c => {
      scores[c.key] = Number(document.getElementById(`num-score-${c.key}`).value);
    });
    const comment = document.getElementById('rate-comment-input').value;

    const submitBtn = document.getElementById('btn-submit-rating');
    submitBtn.disabled = true;
    submitBtn.textContent = '正在同步評分至 Google 試算表...';

    try {
      const res = await fetch(`/api/groups/${groupOrder}/rate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reviewerEmail: state.user.email,
          reviewerName: state.user.name,
          scores,
          comment
        })
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || '評分送出失敗', 'error');
        return;
      }

      await fetchPortalData();
      openRateModal(groupOrder);
      showToast(
        `已成功送出對「第 ${groupOrder} 組」的評分${data.syncedToGoogle ? '，並同步更新 Google 試算表總表！' : '！'}`,
        'success'
      );
    } catch (err) {
      showToast('評分送出異常：' + err.message, 'error');
    } finally {
      submitBtn.disabled = false;
    }
  });

  // Update Own Group Report Info
  document.getElementById('form-update-report-info').addEventListener('submit', async e => {
    e.preventDefault();
    if (!state.user || !state.user.groupOrder) return;

    const btn = document.getElementById('btn-save-group-info');
    btn.disabled = true;
    btn.textContent = '儲存並同步至 Google 試算表中...';

    try {
      const title = document.getElementById('input-report-title').value;
      const sourceUrl = document.getElementById('input-report-source').value;

      const res = await fetch(`/api/groups/${state.user.groupOrder}/info`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          sourceUrl,
          userEmail: state.user.email
        })
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || '更新失敗', 'error');
        return;
      }

      await fetchPortalData();
      showToast('已更新本組報告資訊並同步回寫至 Google 試算表！', 'success');
    } catch (err) {
      showToast('儲存失敗：' + err.message, 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = '儲存並同步更新至 Google 試算表';
    }
  });

  // File Selection & Upload Form
  const fileInput = document.getElementById('input-report-file');
  const fileLabel = document.getElementById('selected-file-label');
  const uploadBtn = document.getElementById('btn-submit-upload');

  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files[0]) {
      const f = fileInput.files[0];
      fileLabel.textContent = `已選擇檔案：${f.name} (${(f.size / 1024).toFixed(1)} KB)`;
      uploadBtn.disabled = false;
    } else {
      fileLabel.textContent = '支援 .pdf, .pptx, .docx（自動命名為「第X組_檔名」上傳至雲端）';
      uploadBtn.disabled = true;
    }
  });

  document.getElementById('form-upload-file').addEventListener('submit', async e => {
    e.preventDefault();
    if (!state.user || !state.user.groupOrder) return;
    if (!fileInput.files || !fileInput.files[0]) return;

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);
    formData.append('uploadedBy', `${state.user.name} (${state.user.id})`);

    uploadBtn.disabled = true;
    uploadBtn.textContent = '正在上傳檔案至網站與 Google Drive 雲端資料夾...';

    try {
      const res = await fetch(`/api/groups/${state.user.groupOrder}/upload`, {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || '上傳失敗', 'error');
        return;
      }

      fileInput.value = '';
      fileLabel.textContent = '支援 .pdf, .pptx, .docx（自動命名為「第X組_檔名」上傳至雲端）';
      await fetchPortalData();
      showToast(
        `簡報「${data.file.name}」上傳成功${data.file.driveUrl ? '，已同步備份至 Google Drive！' : '！'}`,
        'success'
      );
    } catch (err) {
      showToast('檔案上傳錯誤：' + err.message, 'error');
    } finally {
      uploadBtn.disabled = true;
      uploadBtn.textContent = '開始上傳報告檔案至網站與 Google Drive';
    }
  });

  // Manual Sync with Google Sheets Button
  document.getElementById('btn-sync-google').addEventListener('click', async () => {
    const btn = document.getElementById('btn-sync-google');
    btn.disabled = true;
    try {
      const res = await fetch('/api/sync-google', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        showToast(data.message, 'success');
      } else {
        showToast(data.error || '同步失敗', 'error');
      }
    } catch (err) {
      showToast('同步發生錯誤：' + err.message, 'error');
    } finally {
      btn.disabled = false;
    }
  });
}

// ==================== HELPERS ====================
function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

function showToast(msg, type = 'info') {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type === 'success' ? 'toast-success' : type === 'error' ? 'toast-error' : ''}`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => {
    el.remove();
  }, 4200);
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(str) {
  return escapeHtml(str).replace(/'/g, '&#39;');
}

function truncate(str, maxLen) {
  const s = String(str ?? '');
  return s.length > maxLen ? s.slice(0, maxLen) + '…' : s;
}
